<nav class="col-md-3 d-none d-md-block sidebar position-fixed" style="margin-top: 5%;background-color: white">
    <div class="sidebar-sticky ">

        <ul class="nav flex-column">
            <li class="nav-item" >
                <a class="nav-link " href="#">
                    <img class="rounded-circle"  src="/storage/images/{{Auth::user()->utilisateur->photo}}" style="height: 20px; ">
                    {{ucwords(Auth::user()->utilisateur->nom)}}&nbsp;{{ucwords(Auth::user()->utilisateur->prenom)}} <span class="caret"></span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="#">
                    <i class="fa fa-home"></i>
                    Accueill <span class="sr-only">(current)</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <i class="fa fa-envelope"></i>
                    Messages
                </a>
            </li>
            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                <span>Groupes Académiques</span>
                <a class="d-flex align-items-center text-muted" href="#">

                </a>
            </h6>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <i class="fa fa-users"></i>
                    Customers
                </a>
            </li>

        </ul>
    </div>
</nav>