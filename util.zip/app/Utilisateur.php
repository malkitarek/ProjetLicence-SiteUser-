<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Utilisateur extends Model
{
    public function user(){
       return $this->hasOne('App\User');
    }
    public function utilisateurable(){
        return $this->morphTo();
    }
    public function groupe_académiques(){
        return $this->belongsToMany('App\GroupeAcadémique');
    }
}
