@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">


            <div class="col-md-6" style="margin-left: 20%;margin-top: -4%">

                <div class="card  new-post-box">
                    <div class="card-body">
                        <form id="form-new-post">
                            <input type="hidden" name="group_id" value="">
                            <img class="rounded-circle"  src="/storage/images/{{Auth::user()->utilisateur->photo}}" style="height: 40px; ">
                            <textarea name="content" placeholder="Share what you think or photos"></textarea>
                            <div class="image-area">
                                <a href="javascript:;" class="image-remove-button" onclick="removePostImage()"><i class="fa fa-times-circle"></i></a>
                                <img src="" />
                            </div>
                            <hr />
                            <div class="row">
                                <div class="col-xs-4">
                                    <button type="button" class="btn btn-default btn-add-image btn-sm" onclick="uploadPostImage()">
                                        <i class="fa fa-image"></i> Add Image
                                    </button>
                                    <input type="file" accept="image/*" class="image-input" name="photo" onchange="previewPostImage(this)">
                                </div>
                                <div >
                                    <div class="loading-post">
                                        <img src="" alt="">
                                    </div>
                                </div>
                                <div class="col-xs-4" >
                                    <button type="button"  class="btn btn-primary btn-submit pull-right" onclick="newPost()">
                                        Post!
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
