<?php

namespace App\Http\Controllers;

use App\User;
use App\Utilisateur;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AmieController extends Controller
{
    public function retrouver (){
        $id=Auth::user()->id;
        $users=User::all();
        return view('amies.retrouver')->with('users',$users);

    }
}
